(function ($, document) {
    'use strict';

    var DIALOG_SELECTOR = '.cq-dialog';
    var RESOURCE_PATH = 'uf.base.resource_path';

    $(document)
            .on(
                    'dialog-ready',
                    function () {
                        var $dialog = $(document).find(DIALOG_SELECTOR);
                        
                        // set value of resource path
                        
                        var resourcePath = $("[data-listener='" + RESOURCE_PATH +"']").closest(".coral-Form-field");
                        var resourcePathValue = $dialog.attr('action').replace('_jcr_content', 'jcr:content');
                        resourcePath.val(resourcePathValue); 
                        
                    });
})($att, document);