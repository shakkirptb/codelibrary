(function ($, document) {
    'use strict';
    var DATA_EAEM_SELECTOR = 'data-eaem-selector';
    var TEXT_KEY = 'text';
    var VALUE_KEY = 'value';
	
	$(document).on('click', '.coral-Collapsible-header', function () {
        populateDropDownDynamically();
    });

    $(document).on('click', '.js-coral-Multifield-add', function () {
        populateDropDownDynamically();
    });

    $(document).on('dialog-ready', function () {
        populateDropDownDynamically();
    });

    function populateDropDownDynamically() {
		var optionsUrl = "";
        function postProcess(data) {
			console.log("postProcess started ");
            var selectedValue = data[name];

            /*
             * if select field is dynamic drop down
             */
            var dataSelectedValue = $fieldSelect
                    .attr('data-selected-value');
			console.log("postProcess dataSelectedValue =  "+dataSelectedValue);		
            if (dataSelectedValue !== undefined) {
                selectedValue = dataSelectedValue;
            }
			console.log("postProcess selectedValue =  "+selectedValue);	

            $.ajax({
                url : optionsUrl,
                async : false,
                success : function (result) {
                    try{
						console.log("postProcess after ajax call json =  "+result);	
                        var json = result;
						
                        traverse(json, addAndMapOptions, selectedValue,
                                $fieldSelect);
                    }catch(e){
                        return;
                    }
                }
            });
        }
        function traverse(json, func, val, field) {
            if (typeof json == 'object') {
                if (json.length === undefined) {
                    $.each(json, function (k, v) {
                        traverse(v, func, val, field);
                    });
                } else {
                    func(json, val, field);
                }
            }
        }
        function addAndMapOptions(jsonArray, selectedValue, $fieldSelect) {
            var optionElement = $fieldSelect.find("option");
            if(!optionElement.length){
				for (var i = 0; i < jsonArray.length; i++) {
					var entity = jsonArray[i];
					var selectedOption = '';
					var selectedText = '';
					if (selectedValue == entity[VALUE_KEY]) {
						selectedOption = ' selected';
						selectedText = entity[TEXT_KEY];
					}
					$fieldSelect.append('<option value="' + entity.value + '"' + selectedOption + '>' + entity.text + '</option>');
					var selectedClass = '';
					var ariaSelected = "aria-selected='false'";
					if (selectedValue == entity[VALUE_KEY]) {
						selectedClass = ' is-highlighted';
						ariaSelected = "aria-selected='true' tabindex='0'";
					}
					$fieldSelect
							.next()
							.append(
									'<li class="coral-SelectList-item coral-SelectList-item--option ' + selectedClass + '" data-value="' + entity.value + '" role="option" id="coral-analytics-options-' + i + '" ' + ariaSelected + '>' + entity.text + '</li>');
					$fieldSelect.prev().append('<span class="coral-Select-button-text">' + selectedText + '</span>');
				}
			}
        }
        var $dynamicSelectors = $('[' + DATA_EAEM_SELECTOR + ']');
        if (_.isEmpty($dynamicSelectors)) {
            return;
        }
        for (var i = 0; i < $dynamicSelectors.length; i++) {
            var dynamicSelector = $dynamicSelectors[i];
            var $fieldSelect = $(dynamicSelector).find('.coral-Select-select');
            var $form = $('.cq-dialog');
            var actionUrl = $form.attr('action') + '.infinity.json';
			console.log("ActionURL ="+actionUrl);
            var name = $fieldSelect.attr('name');
			console.log("name ="+name);
            if (name !== undefined) {
                // strip ./
                if (name.indexOf('./') === 0) {
                    name = name.substring(2);
					console.log("name with ./="+name);
                }
                optionsUrl = $(dynamicSelector).attr('data-options');
				console.log("optionsUrl ="+optionsUrl);
                $.ajax({
                    url : actionUrl,
                    async : false
                }).done(postProcess);
            }
        }
    }
})($, document);