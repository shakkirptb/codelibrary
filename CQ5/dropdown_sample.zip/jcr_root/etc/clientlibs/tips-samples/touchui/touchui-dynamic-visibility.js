(function ($, document) {
    'use strict';

    $(document)
            .on(
                    'dialog-ready',
                    function () {                        
                        // logic to hide and show the field on the basis of panel layout
                        function layoutHideShowComp(layout) {
                            var $fields = $('[data-visibility]');
                            if (_.isEmpty($fields)) {
                                return;
                            }
                            $fields.each(function (i, field) {
                                var visibilityFactor = $(field).attr('data-visibility');
                                var $requiredFields = $(field).find('[aria-required]');
                                var visibilityArray = visibilityFactor.split(",");
								var layoutVisibilityFlag = false;

                                //loop to identify if visibility contains the current layout
                                $.each( visibilityArray, function( key, value ) {
                                    if(value==layout){
										layoutVisibilityFlag = true;
										return true;
                                    }
                                 });

                                if (layoutVisibilityFlag) {
                                    $requiredFields.each(function (j, requiredField) {
                                        $(requiredField).attr('aria-required', 'true');
                                    });
                                    if ($(field).is('section')) {
                                        $(field).show();
                                    } else {
                                        $(field).parent().show();
                                        if ($(field).parent().hasClass('richtext-container') || $(field).parent().hasClass('coral-Checkbox')) {
                                            $(field).parent().parent().show();
                                        }
                                    }
                                } else {
                                    $requiredFields.each(function (j, requiredField) {
                                        $(requiredField).attr('aria-required', 'false');
                                    });
                                    if ($(field).is('section')) {
                                        $(field).hide();
                                    } else {
                                        $(field).parent().hide();
                                        if ($(field).parent().hasClass('richtext-container') || $(field).parent().hasClass('coral-Checkbox')) {
                                            $(field).parent().parent().hide();
                                        }
                                    }
                                }
                            });
                        }
                        
                        // layout onload
                        var layout = $('[data-visibility-source]').find('.coral-Select-select');
                        layoutHideShowComp(layout.val());

						// layout on change for class showhideRadio
                        $(document).on("change", ".showhideRadio", function () {
							layoutHideShowComp($(this).find("input[aria-selected=true]").val());
  						});

                        // layout onload for class showhideRadio
                        $(".showhideRadio").each(function () {
   							layoutHideShowComp($(this).find("input[aria-selected=true]").val());
    					});
                        // layout on change
                        var layoutSelection = $('[data-visibility-source]');
                        layoutSelection.on('selected.select', function () {
                            var layout = $('[data-visibility-source]').find('.coral-Select-select');
                            layoutHideShowComp(layout.val());
                        });
                    });
})($, document);